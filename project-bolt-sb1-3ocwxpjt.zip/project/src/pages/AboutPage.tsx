import { Link } from 'react-router-dom';
import {
  ShieldCheck, Clock, Users, Heart, Target, Eye, ArrowRight,
  Car, Bus, CheckCircle, Star,
} from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { Reveal } from '@/components/Reveal';

export function AboutPage() {
  const values = [
    { icon: ShieldCheck, title: 'Safety First', desc: 'Every vehicle is regularly serviced and safety-checked to ensure a secure journey for you and your loved ones.' },
    { icon: Clock, title: 'Punctuality', desc: 'We value your time. Our vehicles and drivers are always on schedule, ensuring you reach your destination promptly.' },
    { icon: Heart, title: 'Customer Care', desc: 'Your comfort and satisfaction are our top priorities. We go the extra mile to make your journey pleasant.' },
    { icon: Users, title: 'Experienced Team', desc: 'Our drivers and support staff are experienced, professional, and dedicated to providing excellent service.' },
  ];

  return (
    <div>
      <PageHero
        title="About MSRENTAL"
        subtitle="Your Journey, Our Responsibility — a customer-focused vehicle rental service committed to reliable and comfortable travel."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'About Us' }]}
      />

      {/* Introduction */}
      <section className="section-padding">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <Reveal direction="left">
              <div>
                <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Who We Are</p>
                <h2 className="font-heading font-bold text-3xl text-navy-800 mb-6">
                  Your Trusted Travel Partner
                </h2>
                <p className="text-darknavy leading-relaxed mb-4">
                  MSRENTAL is a customer-focused vehicle rental service offering a wide range of cars and buses
                  for every occasion. Whether you need a compact sedan for a city trip, a spacious SUV for a family
                  vacation, or a comfortable bus for group travel, we have the right vehicle for you.
                </p>
                <p className="text-darknavy leading-relaxed mb-4">
                  [This is editable placeholder text. Replace it with your company story, years of experience,
                  and what makes MSRENTAL unique in your region.]
                </p>
                <p className="text-darknavy leading-relaxed">
                  We believe that every journey should be safe, comfortable, and stress-free. That is why we
                  maintain our vehicles to the highest standards and provide professional, courteous drivers
                  who know the roads well.
                </p>
              </div>
            </Reveal>
            <Reveal direction="right">
              <div className="relative">
                <img
                  src="https://images.pexels.com/photos/27383864/pexels-photo-27383864.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Premium SUV on a countryside road"
                  className="rounded-2xl shadow-xl w-full h-96 object-cover"
                />
                <div className="absolute -bottom-6 -left-6 bg-navy-500 text-white rounded-2xl p-6 shadow-lg hidden md:block">
                  <p className="text-3xl font-bold">11+</p>
                  <p className="text-sm text-navy-100">Vehicles Available</p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Mission and Vision */}
      <section className="bg-lightbg section-padding">
        <div className="container-max">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Reveal direction="left">
              <div className="bg-white rounded-2xl p-8 shadow-md border border-navy-50">
                <div className="bg-sky/10 rounded-full w-14 h-14 flex items-center justify-center mb-5">
                  <Target className="w-7 h-7 text-sky" />
                </div>
                <h3 className="font-heading font-bold text-xl text-navy-800 mb-3">Our Mission</h3>
                <p className="text-darknavy leading-relaxed">
                  To provide safe, reliable, and affordable vehicle rental services that make every journey
                  comfortable and memorable. We strive to be the preferred travel partner for individuals,
                  families, and businesses across the region.
                </p>
                <p className="text-darknavy text-sm mt-3 italic">
                  [Editable placeholder — add your specific mission goals and regional focus.]
                </p>
              </div>
            </Reveal>
            <Reveal direction="right">
              <div className="bg-white rounded-2xl p-8 shadow-md border border-navy-50">
                <div className="bg-sky/10 rounded-full w-14 h-14 flex items-center justify-center mb-5">
                  <Eye className="w-7 h-7 text-sky" />
                </div>
                <h3 className="font-heading font-bold text-xl text-navy-800 mb-3">Our Vision</h3>
                <p className="text-darknavy leading-relaxed">
                  To become the most trusted and widely recognized vehicle rental brand, known for quality
                  service, customer satisfaction, and a fleet that meets every travel need — from daily
                  commutes to grand celebrations.
                </p>
                <p className="text-darknavy text-sm mt-3 italic">
                  [Editable placeholder — add your long-term vision and growth plans.]
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Our Values</p>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                What Drives Us
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((val, i) => (
              <Reveal key={val.title} delay={i * 100}>
                <div className="bg-white rounded-2xl p-6 shadow-md border border-navy-50 text-center card-hover">
                  <div className="bg-navy-50 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                    <val.icon className="w-7 h-7 text-navy-500" />
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">{val.title}</h3>
                  <p className="text-darknavy text-sm">{val.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Vehicle Categories */}
      <section className="bg-lightbg section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                Vehicle Categories We Offer
              </h2>
              <p className="text-darknavy max-w-2xl mx-auto">
                A diverse fleet designed to meet every travel requirement.
              </p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Car, title: 'Sedans', desc: 'Fuel-efficient and comfortable sedans for city travel, business trips, and small families.', link: '/cars?category=sedan' },
              { icon: Car, title: 'SUVs', desc: 'Spacious and powerful SUVs for family vacations, group travel, and outstation journeys.', link: '/cars?category=suv' },
              { icon: Bus, title: 'Buses', desc: 'Comfortable buses for large groups, weddings, corporate outings, and pilgrimage tours.', link: '/buses' },
            ].map((cat, i) => (
              <Reveal key={cat.title} delay={i * 100}>
                <Link
                  to={cat.link}
                  className="block bg-white rounded-2xl p-8 shadow-md card-hover border border-navy-50"
                >
                  <div className="bg-navy-50 rounded-2xl w-16 h-16 flex items-center justify-center mb-5">
                    <cat.icon className="w-8 h-8 text-navy-500" />
                  </div>
                  <h3 className="font-heading font-semibold text-xl text-navy-800 mb-2">{cat.title}</h3>
                  <p className="text-darknavy text-sm mb-4">{cat.desc}</p>
                  <span className="text-sky font-semibold text-sm flex items-center gap-1">
                    Explore <ArrowRight className="w-4 h-4" />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Why Choose MSRENTAL</p>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                Reasons to Ride With Us
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {[
              'Well-maintained, safety-checked vehicles',
              'Competitive and transparent pricing',
              'Professional and experienced drivers',
              'Wide range of vehicles for every need',
              'Flexible pickup and drop-off locations',
              '24/7 customer support via WhatsApp',
              'Easy booking through WhatsApp',
              'AC and non-AC options available',
            ].map((reason, i) => (
              <Reveal key={i} delay={i * 60}>
                <div className="flex items-center gap-3 bg-lightbg rounded-xl p-4">
                  <CheckCircle className="w-5 h-5 text-sky shrink-0" />
                  <span className="text-darknavy text-sm">{reason}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding pt-0">
        <div className="container-max">
          <Reveal>
            <div className="bg-gradient-to-r from-navy-700 to-navy-500 rounded-3xl p-10 md:p-16 text-center text-white">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
                Ready to Start Your Journey?
              </h2>
              <p className="text-navy-100 mb-8 max-w-2xl mx-auto">
                Explore our fleet and find the perfect vehicle for your next trip.
              </p>
              <Link to="/cars" className="btn-primary bg-white text-navy-700 hover:bg-lightbg">
                Explore Vehicles
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
