import { useSearchParams } from 'react-router-dom';
import { Car } from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { VehicleCard } from '@/components/VehicleCard';
import { Reveal } from '@/components/Reveal';
import { useVehicles } from '@/hooks/useVehicles';
import { Link } from 'react-router-dom';

export function CarsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('category') || 'all';

  const { vehicles, loading, error } = useVehicles();
  const filtered = activeCategory === 'all'
    ? vehicles.filter((v) => v.category === 'sedan' || v.category === 'suv')
    : vehicles.filter((v) => v.category === activeCategory);

  const tabs = [
    { key: 'all', label: 'All Cars' },
    { key: 'sedan', label: 'Sedans' },
    { key: 'suv', label: 'SUVs' },
  ];

  return (
    <div>
      <PageHero
        title="Car Collection"
        subtitle="Browse our range of sedans and SUVs, from budget-friendly options to premium luxury vehicles."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'Cars' }]}
      />

      <div className="section-padding">
        <div className="container-max">
          <div className="flex flex-wrap gap-2 mb-10 justify-center">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => {
                  if (tab.key === 'all') setSearchParams({});
                  else setSearchParams({ category: tab.key });
                }}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all ${
                  activeCategory === tab.key
                    ? 'bg-navy-500 text-white shadow-lg shadow-navy-500/20'
                    : 'bg-lightbg text-navy-600 hover:bg-navy-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-lightbg rounded-2xl h-80 animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center text-red-500 py-12">
              <p>Unable to load vehicles. Please try again later.</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16">
              <Car className="w-16 h-16 text-navy-200 mx-auto mb-4" />
              <p className="text-navy-400">No vehicles found in this category.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((v, i) => (
                <Reveal key={v.id} delay={i * 80}>
                  <VehicleCard vehicle={v} />
                </Reveal>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <p className="text-sm text-navy-400 mb-4">
              Prices shown are sample rates and must be confirmed before booking.
            </p>
            <Link to="/buses" className="btn-secondary">
              View Bus Collection
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
