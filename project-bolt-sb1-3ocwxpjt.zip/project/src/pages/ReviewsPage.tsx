import { useEffect, useState } from 'react';
import { MessageCircle, CheckCircle, Star, Users, TrendingUp } from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { Reveal } from '@/components/Reveal';
import { StarRating } from '@/components/StarRating';
import { supabase, type Review } from '@/lib/supabase';
import { buildWhatsAppUrl, buildReviewMessage, formatDate } from '@/lib/utils';

export function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    customerName: '',
    rating: 5,
    vehicleName: '',
    reviewText: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitMode, setSubmitMode] = useState<'whatsapp' | 'website'>('whatsapp');
  const [websiteSubmitted, setWebsiteSubmitted] = useState(false);
  const [whatsappOpened, setWhatsappOpened] = useState(false);

  const fetchReviews = () => {
    supabase
      .from('reviews')
      .select('*')
      .eq('approved', true)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        setReviews(data || []);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchReviews();
  }, []);

  const avgRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!form.customerName.trim()) newErrors.customerName = 'Your name is required';
    if (!form.reviewText.trim()) newErrors.reviewText = 'Please write a review';
    if (form.reviewText.trim().length < 10) newErrors.reviewText = 'Review must be at least 10 characters';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleWhatsAppSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    const msg = buildReviewMessage({
      customerName: form.customerName,
      rating: form.rating,
      vehicleName: form.vehicleName,
      reviewText: form.reviewText,
    });
    window.open(buildWhatsAppUrl(msg), '_blank');
    setWhatsappOpened(true);
  };

  const handleWebsiteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    const { error } = await supabase.from('reviews').insert({
      customer_name: form.customerName,
      rating: form.rating,
      vehicle_name: form.vehicleName,
      review_text: form.reviewText,
      source: 'website',
      approved: false,
    });
    if (error) {
      setErrors({ submit: 'Unable to submit review. Please try again or use WhatsApp.' });
      return;
    }
    setWebsiteSubmitted(true);
    setForm({ customerName: '', rating: 5, vehicleName: '', reviewText: '' });
  };

  return (
    <div>
      <PageHero
        title="Customer Reviews"
        subtitle="Read what our customers say about MSRENTAL, and share your own experience."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'Reviews' }]}
      />

      {/* Stats */}
      <section className="bg-lightbg py-12">
        <div className="container-max px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Reveal>
              <div className="bg-white rounded-2xl p-8 text-center shadow-md border border-navy-50">
                <div className="flex items-center justify-center mb-3">
                  <StarRating rating={Math.round(avgRating)} size="lg" />
                </div>
                <p className="text-3xl font-bold text-navy-500">{avgRating.toFixed(1)}</p>
                <p className="text-sm text-navy-400 mt-1">Average Rating</p>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div className="bg-white rounded-2xl p-8 text-center shadow-md border border-navy-50">
                <Users className="w-10 h-10 text-sky mx-auto mb-3" />
                <p className="text-3xl font-bold text-navy-500">{reviews.length}</p>
                <p className="text-sm text-navy-400 mt-1">Approved Reviews</p>
              </div>
            </Reveal>
            <Reveal delay={200}>
              <div className="bg-white rounded-2xl p-8 text-center shadow-md border border-navy-50">
                <TrendingUp className="w-10 h-10 text-sky mx-auto mb-3" />
                <p className="text-3xl font-bold text-navy-500">100%</p>
                <p className="text-sm text-navy-400 mt-1">Verified Customers</p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Review Form */}
      <section className="section-padding">
        <div className="container-max max-w-3xl">
          <Reveal>
            <div className="bg-white rounded-2xl shadow-xl shadow-navy-500/5 p-8 md:p-10 border border-navy-50">
              <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">Share Your Experience</h2>
              <p className="text-darknavy mb-6">Tell us about your journey with MSRENTAL.</p>

              {/* Mode toggle */}
              <div className="flex gap-2 mb-6 bg-lightbg p-1.5 rounded-full">
                <button
                  onClick={() => { setSubmitMode('whatsapp'); setWebsiteSubmitted(false); setWhatsappOpened(false); }}
                  className={`flex-1 py-2.5 rounded-full text-sm font-semibold transition-all ${submitMode === 'whatsapp' ? 'bg-navy-500 text-white shadow-md' : 'text-navy-500'}`}
                >
                  Via WhatsApp
                </button>
                <button
                  onClick={() => { setSubmitMode('website'); setWebsiteSubmitted(false); setWhatsappOpened(false); }}
                  className={`flex-1 py-2.5 rounded-full text-sm font-semibold transition-all ${submitMode === 'website' ? 'bg-navy-500 text-white shadow-md' : 'text-navy-500'}`}
                >
                  Via Website
                </button>
              </div>

              {websiteSubmitted ? (
                <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">Review Submitted!</h3>
                  <p className="text-darknavy text-sm">
                    Thank you for your review. It will appear on our website after admin approval.
                  </p>
                  <button
                    onClick={() => setWebsiteSubmitted(false)}
                    className="btn-secondary mt-4"
                  >
                    Submit Another Review
                  </button>
                </div>
              ) : whatsappOpened ? (
                <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">WhatsApp Opened!</h3>
                  <p className="text-darknavy text-sm mb-4">
                    WhatsApp has been opened with your review pre-filled. Please send the message to share your review with us.
                  </p>
                  <button
                    onClick={() => setWhatsappOpened(false)}
                    className="btn-secondary"
                  >
                    Submit Another Review
                  </button>
                </div>
              ) : (
                <form onSubmit={submitMode === 'whatsapp' ? handleWhatsAppSubmit : handleWebsiteSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Your Name *</label>
                      <input
                        type="text"
                        value={form.customerName}
                        onChange={(e) => setForm({ ...form, customerName: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.customerName ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="Your name"
                      />
                      {errors.customerName && <p className="text-red-500 text-xs mt-1">{errors.customerName}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Vehicle (optional)</label>
                      <input
                        type="text"
                        value={form.vehicleName}
                        onChange={(e) => setForm({ ...form, vehicleName: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                        placeholder="e.g., Toyota Innova Crysta"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-2">Your Rating *</label>
                    <StarRating
                      rating={form.rating}
                      size="lg"
                      interactive
                      onChange={(r) => setForm({ ...form, rating: r })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">Your Review *</label>
                    <textarea
                      value={form.reviewText}
                      onChange={(e) => setForm({ ...form, reviewText: e.target.value })}
                      rows={4}
                      className={`w-full px-4 py-2.5 rounded-xl border ${errors.reviewText ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all resize-none`}
                      placeholder="Tell us about your experience..."
                    />
                    {errors.reviewText && <p className="text-red-500 text-xs mt-1">{errors.reviewText}</p>}
                  </div>

                  {errors.submit && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
                      {errors.submit}
                    </div>
                  )}

                  <div className="bg-lightbg rounded-xl p-4">
                    <p className="text-xs text-navy-400">
                      {submitMode === 'whatsapp'
                        ? 'WhatsApp will open with your review pre-filled. You must send the message to submit your review.'
                        : 'Website-submitted reviews are reviewed by our admin before appearing publicly. This prevents fake reviews.'}
                    </p>
                  </div>

                  <button type="submit" className={submitMode === 'whatsapp' ? 'btn-whatsapp w-full text-base py-3' : 'btn-primary w-full text-base py-3'}>
                    {submitMode === 'whatsapp' ? (
                      <><MessageCircle className="w-5 h-5" /> Send Review via WhatsApp</>
                    ) : (
                      <>Submit Review</>
                    )}
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </section>

      {/* Reviews Display */}
      <section className="bg-lightbg section-padding">
        <div className="container-max">
          <Reveal>
            <h2 className="font-heading font-bold text-2xl md:text-3xl text-navy-800 mb-8 text-center">
              What Our Customers Say
            </h2>
          </Reveal>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-white rounded-2xl h-48 animate-pulse" />
              ))}
            </div>
          ) : reviews.length === 0 ? (
            <div className="text-center py-12">
              <Star className="w-12 h-12 text-navy-200 mx-auto mb-4" />
              <p className="text-navy-400">No reviews yet. Be the first to share your experience!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {reviews.map((r, i) => (
                <Reveal key={r.id} delay={i * 80}>
                  <div className="bg-white rounded-2xl p-6 shadow-md border border-navy-50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-navy-500 text-white rounded-full w-12 h-12 flex items-center justify-center font-semibold text-lg">
                          {r.customer_name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-semibold text-navy-800">{r.customer_name}</p>
                          {r.vehicle_name && <p className="text-xs text-navy-400">{r.vehicle_name}</p>}
                          <p className="text-xs text-navy-300">{formatDate(r.created_at)}</p>
                        </div>
                      </div>
                      <StarRating rating={r.rating} />
                    </div>
                    <p className="text-darknavy text-sm leading-relaxed">{r.review_text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
