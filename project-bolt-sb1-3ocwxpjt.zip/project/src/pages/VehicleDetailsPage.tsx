import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import {
  Users, Briefcase, Settings, Snowflake, CheckCircle, ArrowLeft,
  MessageCircle, Calendar, MapPin, Phone, Star, Info,
} from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { Reveal } from '@/components/Reveal';
import { useVehicle } from '@/hooks/useVehicles';
import {
  formatPrice, formatCategory, buildWhatsAppUrl, buildBookingMessage,
  validateMobile, calculateDays,
} from '@/lib/utils';
import { supabase } from '@/lib/supabase';

export function VehicleDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { vehicle, loading, error } = useVehicle(id);
  const [activeImage, setActiveImage] = useState(0);
  const [form, setForm] = useState({
    name: '',
    mobile: '',
    pickupLocation: '',
    destination: '',
    pickupDate: '',
    returnDate: '',
    passengers: '1',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-navy-200 border-t-navy-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <p className="text-navy-400 text-lg">Vehicle not found.</p>
        <Link to="/cars" className="btn-primary">Browse Vehicles</Link>
      </div>
    );
  }

  const gallery = vehicle.gallery && vehicle.gallery.length > 0 ? vehicle.gallery : [vehicle.image_url];
  const days = calculateDays(form.pickupDate, form.returnDate);
  const estimatedAmount = days > 0 ? days * vehicle.price_per_day : vehicle.price_per_day;

  const handleBookSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = 'Name is required';
    if (!form.mobile.trim()) newErrors.mobile = 'Mobile number is required';
    else if (!validateMobile(form.mobile)) newErrors.mobile = 'Enter a valid 10-digit Indian mobile number';
    if (!form.pickupLocation.trim()) newErrors.pickupLocation = 'Pickup location is required';
    if (!form.destination.trim()) newErrors.destination = 'Destination is required';
    if (!form.pickupDate) newErrors.pickupDate = 'Pickup date is required';
    if (!form.returnDate) newErrors.returnDate = 'Return date is required';
    if (form.pickupDate && form.returnDate && new Date(form.returnDate) < new Date(form.pickupDate)) {
      newErrors.returnDate = 'Return date cannot be earlier than pickup date';
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    await supabase.from('booking_enquiries').insert({
      customer_name: form.name,
      mobile: form.mobile,
      pickup_location: form.pickupLocation,
      destination: form.destination,
      pickup_datetime: form.pickupDate,
      return_datetime: form.returnDate,
      vehicle_category: vehicle.category,
      vehicle_name: vehicle.name,
      passengers: parseInt(form.passengers) || 1,
    });

    const msg = buildBookingMessage({
      vehicleName: vehicle.name,
      pickupLocation: form.pickupLocation,
      destination: form.destination,
      pickupDate: form.pickupDate,
      returnDate: form.returnDate,
      passengers: form.passengers,
    });
    window.open(buildWhatsAppUrl(msg), '_blank');
    setSubmitted(true);
  };

  return (
    <div>
      <PageHero
        title={vehicle.name}
        subtitle={`${formatCategory(vehicle.category)} • ${formatPrice(vehicle.price_per_day)} per day`}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Cars', path: '/cars' },
          { label: vehicle.name },
        ]}
      />

      <div className="section-padding">
        <div className="container-max">
          <Link to="/cars" className="inline-flex items-center gap-2 text-navy-500 hover:text-navy-700 mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Vehicles
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Gallery */}
            <Reveal direction="left">
              <div>
                <div className="rounded-2xl overflow-hidden shadow-xl mb-4">
                  <img
                    src={gallery[activeImage]}
                    alt={`${vehicle.name} - view ${activeImage + 1}`}
                    className="w-full h-80 object-cover"
                  />
                </div>
                {gallery.length > 1 && (
                  <div className="flex gap-3">
                    {gallery.map((img, i) => (
                      <button
                        key={i}
                        onClick={() => setActiveImage(i)}
                        className={`rounded-xl overflow-hidden w-24 h-20 border-2 transition-all ${
                          activeImage === i ? 'border-navy-500 scale-105' : 'border-transparent opacity-60'
                        }`}
                      >
                        <img src={img} alt={`${vehicle.name} thumbnail ${i + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </Reveal>

            {/* Details */}
            <Reveal direction="right">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-navy-50 text-navy-500 text-sm font-semibold px-3 py-1 rounded-full">
                    {formatCategory(vehicle.category)}
                  </span>
                  {vehicle.available ? (
                    <span className="bg-green-50 text-green-600 text-sm font-semibold px-3 py-1 rounded-full flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Available
                    </span>
                  ) : (
                    <span className="bg-red-50 text-red-600 text-sm font-semibold px-3 py-1 rounded-full">
                      Not Available
                    </span>
                  )}
                </div>

                <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">{vehicle.name}</h2>
                <p className="text-3xl font-bold text-navy-500 mb-6">
                  {formatPrice(vehicle.price_per_day)}
                  <span className="text-base font-normal text-navy-300">/day</span>
                </p>

                <p className="text-darknavy mb-6 leading-relaxed">{vehicle.description}</p>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {[
                    { icon: Users, label: 'Passengers', value: `${vehicle.passengers} Seater` },
                    { icon: Briefcase, label: 'Luggage', value: `${vehicle.luggage} Bags` },
                    { icon: Settings, label: 'Transmission', value: vehicle.transmission },
                    { icon: Snowflake, label: 'Air Conditioning', value: vehicle.ac ? 'Yes' : 'No' },
                  ].map((spec) => (
                    <div key={spec.label} className="flex items-center gap-3 bg-lightbg rounded-xl p-4">
                      <spec.icon className="w-5 h-5 text-sky" />
                      <div>
                        <p className="text-xs text-navy-400">{spec.label}</p>
                        <p className="text-sm font-semibold text-navy-800">{spec.value}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Features */}
                {vehicle.features && vehicle.features.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-heading font-semibold text-navy-800 mb-3">Features</h3>
                    <div className="flex flex-wrap gap-2">
                      {vehicle.features.map((f) => (
                        <span key={f} className="bg-navy-50 text-navy-600 text-sm px-3 py-1.5 rounded-full flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5 text-sky" />
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Rental Conditions */}
                <div className="bg-lightbg rounded-xl p-5 mb-6">
                  <h3 className="font-heading font-semibold text-navy-800 mb-3 flex items-center gap-2">
                    <Info className="w-4 h-4 text-sky" />
                    Rental Conditions
                  </h3>
                  <ul className="text-sm text-darknavy space-y-2">
                    <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-sky mt-0.5" /> Valid driving license required for self-drive option</li>
                    <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-sky mt-0.5" /> Professional driver available on request</li>
                    <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-sky mt-0.5" /> Fuel charges as per actuals</li>
                    <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-sky mt-0.5" /> Toll and parking charges extra</li>
                    <li className="flex items-start gap-2"><CheckCircle className="w-4 h-4 text-sky mt-0.5" /> Final price confirmed upon booking</li>
                  </ul>
                </div>

                <a
                  href={buildWhatsAppUrl(buildBookingMessage({ vehicleName: vehicle.name }))}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-whatsapp w-full text-base py-3"
                >
                  <MessageCircle className="w-5 h-5" />
                  Book on WhatsApp
                </a>
              </div>
            </Reveal>
          </div>

          {/* Booking Form */}
          <div className="mt-16">
            <Reveal>
              <div className="bg-lightbg rounded-2xl p-8 md:p-10">
                <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">
                  Book This Vehicle
                </h2>
                <p className="text-darknavy mb-6">
                  Fill in your details and we'll prepare a booking enquiry for {vehicle.name}.
                </p>

                {submitted ? (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="font-heading font-semibold text-xl text-navy-800 mb-2">
                      Booking Request Prepared!
                    </h3>
                    <p className="text-darknavy mb-4">
                      Your booking enquiry has been prepared and WhatsApp has been opened with your details.
                      Please send the WhatsApp message to complete your enquiry.
                    </p>
                    <p className="text-sm text-navy-400 mb-6">
                      Your booking is not confirmed until MSRENTAL confirms availability and final pricing.
                    </p>
                    <button
                      onClick={() => { setSubmitted(false); navigate('/book'); }}
                      className="btn-primary"
                    >
                      Go to Full Booking Page
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleBookSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Full Name *</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.name ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="Your name"
                      />
                      {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Mobile Number *</label>
                      <input
                        type="tel"
                        value={form.mobile}
                        onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.mobile ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="10-digit mobile number"
                      />
                      {errors.mobile && <p className="text-red-500 text-xs mt-1">{errors.mobile}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Location *</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                        <input
                          type="text"
                          value={form.pickupLocation}
                          onChange={(e) => setForm({ ...form, pickupLocation: e.target.value })}
                          className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${errors.pickupLocation ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                          placeholder="Pickup location"
                        />
                      </div>
                      {errors.pickupLocation && <p className="text-red-500 text-xs mt-1">{errors.pickupLocation}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Destination *</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                        <input
                          type="text"
                          value={form.destination}
                          onChange={(e) => setForm({ ...form, destination: e.target.value })}
                          className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${errors.destination ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                          placeholder="Destination"
                        />
                      </div>
                      {errors.destination && <p className="text-red-500 text-xs mt-1">{errors.destination}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Date *</label>
                      <input
                        type="date"
                        value={form.pickupDate}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setForm({ ...form, pickupDate: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.pickupDate ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                      />
                      {errors.pickupDate && <p className="text-red-500 text-xs mt-1">{errors.pickupDate}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Return Date *</label>
                      <input
                        type="date"
                        value={form.returnDate}
                        min={form.pickupDate || new Date().toISOString().split('T')[0]}
                        onChange={(e) => setForm({ ...form, returnDate: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.returnDate ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                      />
                      {errors.returnDate && <p className="text-red-500 text-xs mt-1">{errors.returnDate}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Passengers</label>
                      <input
                        type="number"
                        min="1"
                        value={form.passengers}
                        onChange={(e) => setForm({ ...form, passengers: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                      />
                    </div>
                    <div className="md:col-span-2">
                      {days > 0 && (
                        <div className="bg-navy-50 rounded-xl p-4 mb-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-navy-600">Estimated Rental Duration</span>
                            <span className="font-semibold text-navy-800">{days} day{days > 1 ? 's' : ''}</span>
                          </div>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-sm text-navy-600">Estimated Amount</span>
                            <span className="font-bold text-xl text-navy-500">
                              {formatPrice(estimatedAmount)}
                            </span>
                          </div>
                          <p className="text-xs text-navy-400 mt-2">
                            * This is an estimate based on daily rate. Final price depends on confirmed rental terms.
                          </p>
                        </div>
                      )}
                      <button type="submit" className="btn-primary w-full">
                        <MessageCircle className="w-5 h-5" />
                        Submit Booking Enquiry
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </div>
  );
}
