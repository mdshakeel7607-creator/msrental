import { useEffect, useState } from 'react';
import { MessageCircle, CheckCircle, Info, MapPin, Users, Calendar, Car } from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { Reveal } from '@/components/Reveal';
import { supabase, type Vehicle } from '@/lib/supabase';
import {
  buildWhatsAppUrl, buildBookingMessage, formatPrice, formatCategory,
  validateMobile, calculateDays,
} from '@/lib/utils';

export function BookNowPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    pickupLocation: '',
    destination: '',
    pickupDate: '',
    pickupTime: '',
    returnDate: '',
    returnTime: '',
    vehicleCategory: '',
    vehicleName: '',
    passengers: '1',
    additionalRequirements: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    supabase.from('vehicles').select('*').order('price_per_day', { ascending: true }).then(({ data }) => {
      setVehicles(data || []);
    });
  }, []);

  const filteredVehicles = form.vehicleCategory
    ? vehicles.filter((v) => v.category === form.vehicleCategory)
    : vehicles;

  const selectedVehicle = vehicles.find((v) => v.name === form.vehicleName);
  const days = calculateDays(form.pickupDate, form.returnDate);
  const estimatedAmount = selectedVehicle && days > 0
    ? days * selectedVehicle.price_per_day
    : selectedVehicle?.price_per_day || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = 'Name is required';
    if (!form.mobile.trim()) newErrors.mobile = 'Mobile number is required';
    else if (!validateMobile(form.mobile)) newErrors.mobile = 'Enter a valid 10-digit Indian mobile number';
    if (!form.pickupLocation.trim()) newErrors.pickupLocation = 'Pickup location is required';
    if (!form.destination.trim()) newErrors.destination = 'Destination is required';
    if (!form.pickupDate) newErrors.pickupDate = 'Pickup date is required';
    if (!form.returnDate) newErrors.returnDate = 'Return date is required';
    if (form.pickupDate && form.returnDate && new Date(form.returnDate) < new Date(form.pickupDate)) {
      newErrors.returnDate = 'Return date cannot be earlier than pickup date';
    }
    if (!form.vehicleCategory) newErrors.vehicleCategory = 'Please select a vehicle category';
    if (!form.vehicleName) newErrors.vehicleName = 'Please select a vehicle';
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    setSubmitting(true);

    await supabase.from('booking_enquiries').insert({
      customer_name: form.name,
      mobile: form.mobile,
      email: form.email,
      pickup_location: form.pickupLocation,
      destination: form.destination,
      pickup_datetime: `${form.pickupDate} ${form.pickupTime || 'N/A'}`,
      return_datetime: `${form.returnDate} ${form.returnTime || 'N/A'}`,
      vehicle_category: form.vehicleCategory,
      vehicle_name: form.vehicleName,
      passengers: parseInt(form.passengers) || 1,
      additional_requirements: form.additionalRequirements,
    });

    const msg = buildBookingMessage({
      vehicleName: form.vehicleName,
      pickupLocation: form.pickupLocation,
      destination: form.destination,
      pickupDate: `${form.pickupDate}${form.pickupTime ? ` ${form.pickupTime}` : ''}`,
      returnDate: `${form.returnDate}${form.returnTime ? ` ${form.returnTime}` : ''}`,
      passengers: form.passengers,
    });
    window.open(buildWhatsAppUrl(msg), '_blank');
    setSubmitting(false);
    setSubmitted(true);
  };

  return (
    <div>
      <PageHero
        title="Book Your Ride"
        subtitle="Fill in your details below to submit a booking enquiry. We'll confirm availability and pricing via WhatsApp."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'Book Now' }]}
      />

      <div className="section-padding">
        <div className="container-max max-w-4xl">
          {submitted ? (
            <Reveal>
              <div className="bg-green-50 border border-green-200 rounded-2xl p-10 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-6" />
                <h2 className="font-heading font-bold text-2xl text-navy-800 mb-3">
                  Booking Request Prepared!
                </h2>
                <p className="text-darknavy mb-4 max-w-lg mx-auto">
                  Your booking enquiry has been prepared and WhatsApp has been opened with your details.
                  Please send the WhatsApp message to complete your enquiry.
                </p>
                <div className="bg-white rounded-xl p-5 max-w-md mx-auto mb-6 text-left">
                  <p className="text-sm text-navy-400 mb-1">Vehicle Requested</p>
                  <p className="font-semibold text-navy-800">{form.vehicleName}</p>
                  <p className="text-sm text-navy-400 mt-3 mb-1">Pickup</p>
                  <p className="text-sm text-navy-700">{form.pickupLocation} — {form.pickupDate}</p>
                  <p className="text-sm text-navy-400 mt-3 mb-1">Return</p>
                  <p className="text-sm text-navy-700">{form.returnDate}</p>
                  {estimatedAmount > 0 && (
                    <>
                      <p className="text-sm text-navy-400 mt-3 mb-1">Estimated Amount</p>
                      <p className="font-bold text-navy-500">{formatPrice(estimatedAmount)}</p>
                    </>
                  )}
                </div>
                <p className="text-sm text-navy-400 mb-6">
                  Your booking is not confirmed until MSRENTAL confirms availability and final pricing.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setForm({
                      name: '', mobile: '', email: '', pickupLocation: '', destination: '',
                      pickupDate: '', pickupTime: '', returnDate: '', returnTime: '',
                      vehicleCategory: '', vehicleName: '', passengers: '1', additionalRequirements: '',
                    });
                  }}
                  className="btn-secondary"
                >
                  Submit Another Enquiry
                </button>
              </div>
            </Reveal>
          ) : (
            <Reveal>
              <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl shadow-navy-500/5 p-8 md:p-10 border border-navy-50">
                <div className="mb-8">
                  <h2 className="font-heading font-bold text-xl text-navy-800 mb-2">Customer Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Full Name *</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.name ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="Your full name"
                      />
                      {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Mobile Number *</label>
                      <input
                        type="tel"
                        value={form.mobile}
                        onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.mobile ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="10-digit mobile number"
                      />
                      {errors.mobile && <p className="text-red-500 text-xs mt-1">{errors.mobile}</p>}
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-navy-600 mb-1">Email (optional)</label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                </div>

                <div className="mb-8">
                  <h2 className="font-heading font-bold text-xl text-navy-800 mb-2">Trip Details</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Location *</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                        <input
                          type="text"
                          value={form.pickupLocation}
                          onChange={(e) => setForm({ ...form, pickupLocation: e.target.value })}
                          className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${errors.pickupLocation ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                          placeholder="Pickup location"
                        />
                      </div>
                      {errors.pickupLocation && <p className="text-red-500 text-xs mt-1">{errors.pickupLocation}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Destination *</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                        <input
                          type="text"
                          value={form.destination}
                          onChange={(e) => setForm({ ...form, destination: e.target.value })}
                          className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${errors.destination ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                          placeholder="Destination"
                        />
                      </div>
                      {errors.destination && <p className="text-red-500 text-xs mt-1">{errors.destination}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Date *</label>
                      <input
                        type="date"
                        value={form.pickupDate}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setForm({ ...form, pickupDate: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.pickupDate ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                      />
                      {errors.pickupDate && <p className="text-red-500 text-xs mt-1">{errors.pickupDate}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Time</label>
                      <input
                        type="time"
                        value={form.pickupTime}
                        onChange={(e) => setForm({ ...form, pickupTime: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Return Date *</label>
                      <input
                        type="date"
                        value={form.returnDate}
                        min={form.pickupDate || new Date().toISOString().split('T')[0]}
                        onChange={(e) => setForm({ ...form, returnDate: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.returnDate ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                      />
                      {errors.returnDate && <p className="text-red-500 text-xs mt-1">{errors.returnDate}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Return Time</label>
                      <input
                        type="time"
                        value={form.returnTime}
                        onChange={(e) => setForm({ ...form, returnTime: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="mb-8">
                  <h2 className="font-heading font-bold text-xl text-navy-800 mb-2">Vehicle Selection</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Vehicle Category *</label>
                      <select
                        value={form.vehicleCategory}
                        onChange={(e) => setForm({ ...form, vehicleCategory: e.target.value, vehicleName: '' })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.vehicleCategory ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all bg-white`}
                      >
                        <option value="">Select category</option>
                        <option value="sedan">Sedan</option>
                        <option value="suv">SUV</option>
                        <option value="bus">Bus</option>
                      </select>
                      {errors.vehicleCategory && <p className="text-red-500 text-xs mt-1">{errors.vehicleCategory}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Select Vehicle *</label>
                      <select
                        value={form.vehicleName}
                        onChange={(e) => setForm({ ...form, vehicleName: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.vehicleName ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all bg-white`}
                        disabled={!form.vehicleCategory}
                      >
                        <option value="">Select vehicle</option>
                        {filteredVehicles.map((v) => (
                          <option key={v.id} value={v.name}>
                            {v.name} — {formatPrice(v.price_per_day)}/day
                          </option>
                        ))}
                      </select>
                      {errors.vehicleName && <p className="text-red-500 text-xs mt-1">{errors.vehicleName}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Number of Passengers</label>
                      <div className="relative">
                        <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                        <input
                          type="number"
                          min="1"
                          value={form.passengers}
                          onChange={(e) => setForm({ ...form, passengers: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  {selectedVehicle && days > 0 && (
                    <div className="bg-navy-50 rounded-xl p-5 mt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Car className="w-5 h-5 text-navy-500" />
                        <span className="font-semibold text-navy-800">{selectedVehicle.name}</span>
                        <span className="text-sm text-navy-400">({formatPrice(selectedVehicle.price_per_day)}/day)</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-navy-600">Estimated Duration: {days} day{days > 1 ? 's' : ''}</span>
                        <span className="font-bold text-2xl text-navy-500">{formatPrice(estimatedAmount)}</span>
                      </div>
                      <p className="text-xs text-navy-400 mt-2 flex items-center gap-1">
                        <Info className="w-3.5 h-3.5" />
                        This is an estimate. Final price depends on confirmed rental terms.
                      </p>
                    </div>
                  )}
                </div>

                <div className="mb-8">
                  <label className="block text-sm font-medium text-navy-600 mb-1">Additional Requirements</label>
                  <textarea
                    value={form.additionalRequirements}
                    onChange={(e) => setForm({ ...form, additionalRequirements: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all resize-none"
                    placeholder="Any special requests like child seat, driver, extra stops, etc."
                  />
                </div>

                <div className="bg-lightbg rounded-xl p-4 mb-6">
                  <p className="text-sm text-navy-400 flex items-start gap-2">
                    <Info className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                    On submission, WhatsApp will open with your booking details pre-filled. Please send the message to complete your enquiry. Your booking is not confirmed until MSRENTAL confirms.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary w-full text-base py-3.5 disabled:opacity-60"
                >
                  {submitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Preparing...
                    </>
                  ) : (
                    <>
                      <MessageCircle className="w-5 h-5" />
                      Submit Booking Enquiry
                    </>
                  )}
                </button>
              </form>
            </Reveal>
          )}
        </div>
      </div>
    </div>
  );
}
