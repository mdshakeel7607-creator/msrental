import { useState, useEffect } from 'react';
import {
  LogOut, Car, Star, Calendar, Settings, Plus, Edit2, Trash2,
  Check, X, Clock, Phone, MapPin, Users, Package, TrendingUp,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Vehicle, type Review, type BookingEnquiry, type BusinessSettings } from '@/lib/supabase';
import { formatPrice, formatCategory, formatDate } from '@/lib/utils';

type Tab = 'vehicles' | 'reviews' | 'bookings' | 'settings';

export function AdminPage() {
  const { user, isAdmin, loading, signOut, signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [tab, setTab] = useState<Tab>('vehicles');

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [bookings, setBookings] = useState<BookingEnquiry[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | null>(null);
  const [dataLoading, setDataLoading] = useState(false);

  // Edit states
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [showVehicleForm, setShowVehicleForm] = useState(false);
  const [settingsForm, setSettingsForm] = useState({ business_name: '', whatsapp_number: '', address: '', business_hours: '', email: '' });
  const [settingsSaved, setSettingsSaved] = useState(false);

  const fetchAll = async () => {
    setDataLoading(true);
    const [vRes, rRes, bRes, sRes] = await Promise.all([
      supabase.from('vehicles').select('*').order('created_at', { ascending: false }),
      supabase.from('reviews').select('*').order('created_at', { ascending: false }),
      supabase.from('booking_enquiries').select('*').order('created_at', { ascending: false }),
      supabase.from('business_settings').select('*').maybeSingle(),
    ]);
    setVehicles(vRes.data || []);
    setReviews(rRes.data || []);
    setBookings(bRes.data || []);
    if (sRes.data) {
      setSettings(sRes.data);
      setSettingsForm({
        business_name: sRes.data.business_name,
        whatsapp_number: sRes.data.whatsapp_number,
        address: sRes.data.address,
        business_hours: sRes.data.business_hours,
        email: sRes.data.email,
      });
    }
    setDataLoading(false);
  };

  useEffect(() => {
    if (isAdmin) fetchAll();
  }, [isAdmin]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const { error } = await signIn(email, password);
    if (error) setLoginError(error);
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-navy-200 border-t-navy-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full border border-navy-50">
          <div className="text-center mb-6">
            <div className="bg-navy-500 rounded-2xl w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Settings className="w-8 h-8 text-white" />
            </div>
            <h1 className="font-heading font-bold text-2xl text-navy-800">Admin Login</h1>
            <p className="text-darknavy text-sm mt-2">Sign in to manage MSRENTAL</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-navy-600 mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                placeholder="admin@msrental.com"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-navy-600 mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                placeholder="Your password"
                required
              />
            </div>
            {loginError && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-600">
                {loginError}
              </div>
            )}
            <button type="submit" className="btn-primary w-full">Sign In</button>
          </form>
          <p className="text-xs text-navy-400 text-center mt-4">
            Admin access is restricted. Contact your administrator if you need credentials.
          </p>
        </div>
      </div>
    );
  }

  const tabs: { key: Tab; label: string; icon: typeof Car; count?: number }[] = [
    { key: 'vehicles', label: 'Vehicles', icon: Car, count: vehicles.length },
    { key: 'reviews', label: 'Reviews', icon: Star, count: reviews.filter((r) => !r.approved).length },
    { key: 'bookings', label: 'Bookings', icon: Calendar, count: bookings.filter((b) => b.status === 'pending').length },
    { key: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleApproveReview = async (id: string, approve: boolean) => {
    if (approve) {
      await supabase.from('reviews').update({ approved: true }).eq('id', id);
    } else {
      await supabase.from('reviews').delete().eq('id', id);
    }
    fetchAll();
  };

  const handleDeleteVehicle = async (id: string) => {
    if (!confirm('Are you sure you want to delete this vehicle?')) return;
    await supabase.from('vehicles').delete().eq('id', id);
    fetchAll();
  };

  const handleSaveVehicle = async (v: Partial<Vehicle>) => {
    if (editingVehicle?.id) {
      await supabase.from('vehicles').update({
        name: v.name, category: v.category, price_per_day: v.price_per_day,
        passengers: v.passengers, luggage: v.luggage, transmission: v.transmission,
        ac: v.ac, image_url: v.image_url, features: v.features,
        description: v.description, available: v.available, updated_at: new Date().toISOString(),
      }).eq('id', editingVehicle.id);
    } else {
      await supabase.from('vehicles').insert({
        name: v.name, category: v.category, price_per_day: v.price_per_day,
        passengers: v.passengers, luggage: v.luggage, transmission: v.transmission,
        ac: v.ac, image_url: v.image_url, features: v.features || [],
        description: v.description || '', available: v.available ?? true,
        gallery: [v.image_url],
      });
    }
    setShowVehicleForm(false);
    setEditingVehicle(null);
    fetchAll();
  };

  const handleSaveSettings = async () => {
    if (!settings) return;
    await supabase.from('business_settings').update(settingsForm).eq('id', settings.id);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
    fetchAll();
  };

  const updateBookingStatus = async (id: string, status: string) => {
    await supabase.from('booking_enquiries').update({ status }).eq('id', id);
    fetchAll();
  };

  return (
    <div className="min-h-screen bg-lightbg">
      {/* Admin Header */}
      <div className="bg-navy-800 text-white">
        <div className="container-max px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div>
            <h1 className="font-heading font-bold text-2xl">MSRENTAL Admin</h1>
            <p className="text-navy-200 text-sm">Welcome, {user.email}</p>
          </div>
          <button
            onClick={signOut}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-full text-sm transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="container-max px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { icon: Car, label: 'Total Vehicles', value: vehicles.length },
            { icon: Star, label: 'Pending Reviews', value: reviews.filter((r) => !r.approved).length },
            { icon: Calendar, label: 'Pending Bookings', value: bookings.filter((b) => b.status === 'pending').length },
            { icon: TrendingUp, label: 'Total Bookings', value: bookings.length },
          ].map((stat, i) => (
            <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-navy-50">
              <stat.icon className="w-6 h-6 text-sky mb-2" />
              <p className="text-2xl font-bold text-navy-800">{stat.value}</p>
              <p className="text-xs text-navy-400">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                tab === t.key ? 'bg-navy-500 text-white shadow-md' : 'bg-white text-navy-600 hover:bg-navy-50 border border-navy-50'
              }`}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
              {t.count !== undefined && t.count > 0 && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${tab === t.key ? 'bg-white/20' : 'bg-red-100 text-red-600'}`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {dataLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-navy-200 border-t-navy-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div>
            {/* Vehicles Tab */}
            {tab === 'vehicles' && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-heading font-semibold text-lg text-navy-800">Vehicle Listings</h2>
                  <button
                    onClick={() => { setEditingVehicle(null); setShowVehicleForm(true); }}
                    className="btn-primary text-sm"
                  >
                    <Plus className="w-4 h-4" /> Add Vehicle
                  </button>
                </div>

                {showVehicleForm && (
                  <VehicleForm
                    vehicle={editingVehicle}
                    onSave={handleSaveVehicle}
                    onCancel={() => { setShowVehicleForm(false); setEditingVehicle(null); }}
                  />
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vehicles.map((v) => (
                    <div key={v.id} className="bg-white rounded-xl shadow-sm border border-navy-50 overflow-hidden">
                      <img src={v.image_url} alt={v.name} className="w-full h-40 object-cover" />
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-navy-800">{v.name}</h3>
                            <p className="text-xs text-navy-400">{formatCategory(v.category)} • {formatPrice(v.price_per_day)}/day</p>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${v.available ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                            {v.available ? 'Available' : 'Unavailable'}
                          </span>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button
                            onClick={() => { setEditingVehicle(v); setShowVehicleForm(true); }}
                            className="flex-1 flex items-center justify-center gap-1 bg-navy-50 text-navy-600 rounded-lg py-2 text-xs font-semibold hover:bg-navy-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" /> Edit
                          </button>
                          <button
                            onClick={() => handleDeleteVehicle(v.id)}
                            className="flex-1 flex items-center justify-center gap-1 bg-red-50 text-red-600 rounded-lg py-2 text-xs font-semibold hover:bg-red-100 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews Tab */}
            {tab === 'reviews' && (
              <div>
                <h2 className="font-heading font-semibold text-lg text-navy-800 mb-4">Customer Reviews</h2>
                <div className="space-y-3">
                  {reviews.map((r) => (
                    <div key={r.id} className={`bg-white rounded-xl p-5 shadow-sm border ${r.approved ? 'border-green-200' : 'border-amber-200'}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="font-semibold text-navy-800">{r.customer_name}</span>
                            <span className="flex items-center gap-0.5">
                              {[1, 2, 3, 4, 5].map((s) => (
                                <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? 'fill-amber-400 text-amber-400' : 'fill-gray-200 text-gray-200'}`} />
                              ))}
                            </span>
                            <span className={`text-xs px-2 py-0.5 rounded-full ${r.approved ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}`}>
                              {r.approved ? 'Approved' : 'Pending'}
                            </span>
                            <span className="text-xs text-navy-400">{r.source}</span>
                          </div>
                          {r.vehicle_name && <p className="text-xs text-navy-400 mb-1">Vehicle: {r.vehicle_name}</p>}
                          <p className="text-darknavy text-sm">{r.review_text}</p>
                          <p className="text-xs text-navy-300 mt-2">{formatDate(r.created_at)}</p>
                        </div>
                        {!r.approved && (
                          <div className="flex gap-2 ml-4 shrink-0">
                            <button
                              onClick={() => handleApproveReview(r.id, true)}
                              className="bg-green-50 text-green-600 rounded-lg p-2 hover:bg-green-100 transition-colors"
                              title="Approve"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleApproveReview(r.id, false)}
                              className="bg-red-50 text-red-600 rounded-lg p-2 hover:bg-red-100 transition-colors"
                              title="Reject"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                        {r.approved && (
                          <button
                            onClick={() => handleApproveReview(r.id, false)}
                            className="bg-red-50 text-red-600 rounded-lg p-2 hover:bg-red-100 transition-colors ml-4 shrink-0"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                  {reviews.length === 0 && <p className="text-navy-400 text-center py-8">No reviews yet.</p>}
                </div>
              </div>
            )}

            {/* Bookings Tab */}
            {tab === 'bookings' && (
              <div>
                <h2 className="font-heading font-semibold text-lg text-navy-800 mb-4">Booking Enquiries</h2>
                <div className="space-y-3">
                  {bookings.map((b) => (
                    <div key={b.id} className="bg-white rounded-xl p-5 shadow-sm border border-navy-50">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                          <p className="text-xs text-navy-400 mb-1">Customer</p>
                          <p className="font-semibold text-navy-800 text-sm">{b.customer_name}</p>
                          <p className="text-sm text-darknavy flex items-center gap-1 mt-1"><Phone className="w-3.5 h-3.5 text-sky" />{b.mobile}</p>
                          {b.email && <p className="text-sm text-darknavy">{b.email}</p>}
                        </div>
                        <div>
                          <p className="text-xs text-navy-400 mb-1">Trip Details</p>
                          <p className="text-sm text-darknavy flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-sky" />{b.pickup_location} to {b.destination}</p>
                          <p className="text-sm text-darknavy mt-1">Pickup: {b.pickup_datetime}</p>
                          <p className="text-sm text-darknavy">Return: {b.return_datetime}</p>
                        </div>
                        <div>
                          <p className="text-xs text-navy-400 mb-1">Vehicle</p>
                          <p className="text-sm font-semibold text-navy-800">{b.vehicle_name}</p>
                          <p className="text-sm text-darknavy flex items-center gap-1 mt-1"><Users className="w-3.5 h-3.5 text-sky" />{b.passengers} passengers</p>
                          {b.additional_requirements && <p className="text-xs text-navy-400 mt-1">{b.additional_requirements}</p>}
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-navy-50">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
                            b.status === 'pending' ? 'bg-amber-100 text-amber-600' :
                            b.status === 'confirmed' ? 'bg-green-100 text-green-600' :
                            b.status === 'completed' ? 'bg-blue-100 text-blue-600' :
                            'bg-red-100 text-red-600'
                          }`}>
                            {b.status}
                          </span>
                          <span className="text-xs text-navy-300">{formatDate(b.created_at)}</span>
                        </div>
                        <select
                          value={b.status}
                          onChange={(e) => updateBookingStatus(b.id, e.target.value)}
                          className="text-sm px-3 py-1.5 rounded-lg border border-navy-100 bg-white outline-none focus:ring-2 focus:ring-sky"
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                  ))}
                  {bookings.length === 0 && <p className="text-navy-400 text-center py-8">No booking enquiries yet.</p>}
                </div>
              </div>
            )}

            {/* Settings Tab */}
            {tab === 'settings' && (
              <div className="bg-white rounded-xl p-8 shadow-sm border border-navy-50 max-w-2xl">
                <h2 className="font-heading font-semibold text-lg text-navy-800 mb-6">Business Settings</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">Business Name</label>
                    <input
                      type="text"
                      value={settingsForm.business_name}
                      onChange={(e) => setSettingsForm({ ...settingsForm, business_name: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">WhatsApp Number</label>
                    <input
                      type="text"
                      value={settingsForm.whatsapp_number}
                      onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp_number: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">Address</label>
                    <input
                      type="text"
                      value={settingsForm.address}
                      onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">Business Hours</label>
                    <input
                      type="text"
                      value={settingsForm.business_hours}
                      onChange={(e) => setSettingsForm({ ...settingsForm, business_hours: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-navy-600 mb-1">Email</label>
                    <input
                      type="email"
                      value={settingsForm.email}
                      onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all"
                    />
                  </div>
                  <div className="flex items-center gap-4">
                    <button onClick={handleSaveSettings} className="btn-primary">
                      <Package className="w-4 h-4" /> Save Settings
                    </button>
                    {settingsSaved && <span className="text-green-600 text-sm flex items-center gap-1"><Check className="w-4 h-4" /> Saved!</span>}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function VehicleForm({
  vehicle,
  onSave,
  onCancel,
}: {
  vehicle: Vehicle | null;
  onSave: (v: Partial<Vehicle>) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name: vehicle?.name || '',
    category: vehicle?.category || 'sedan',
    price_per_day: vehicle?.price_per_day || 5000,
    passengers: vehicle?.passengers || 5,
    luggage: vehicle?.luggage || 3,
    transmission: vehicle?.transmission || 'Manual',
    ac: vehicle?.ac ?? true,
    image_url: vehicle?.image_url || '',
    features: vehicle?.features?.join(', ') || '',
    description: vehicle?.description || '',
    available: vehicle?.available ?? true,
  });

  return (
    <div className="bg-white rounded-xl p-6 shadow-md border border-navy-50 mb-6">
      <h3 className="font-heading font-semibold text-lg text-navy-800 mb-4">
        {vehicle ? 'Edit Vehicle' : 'Add New Vehicle'}
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Name *</label>
          <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Category *</label>
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as 'sedan' | 'suv' | 'bus' })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm bg-white">
            <option value="sedan">Sedan</option>
            <option value="suv">SUV</option>
            <option value="bus">Bus</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Price/Day (INR) *</label>
          <input type="number" value={form.price_per_day} onChange={(e) => setForm({ ...form, price_per_day: parseInt(e.target.value) || 0 })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Passengers</label>
          <input type="number" value={form.passengers} onChange={(e) => setForm({ ...form, passengers: parseInt(e.target.value) || 1 })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Luggage</label>
          <input type="number" value={form.luggage} onChange={(e) => setForm({ ...form, luggage: parseInt(e.target.value) || 0 })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-navy-600 mb-1">Transmission</label>
          <select value={form.transmission} onChange={(e) => setForm({ ...form, transmission: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm bg-white">
            <option value="Manual">Manual</option>
            <option value="Automatic">Automatic</option>
            <option value="N/A">N/A</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-navy-600 mb-1">Image URL *</label>
          <input type="text" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm"
            placeholder="https://..." />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-navy-600 mb-1">Features (comma-separated)</label>
          <input type="text" value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm"
            placeholder="AC, Sunroof, Music System" />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-navy-600 mb-1">Description</label>
          <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            rows={3} className="w-full px-3 py-2 rounded-lg border border-navy-100 focus:ring-2 focus:ring-sky outline-none text-sm resize-none" />
        </div>
        <div className="md:col-span-2">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.available} onChange={(e) => setForm({ ...form, available: e.target.checked })}
              className="w-4 h-4 rounded text-sky focus:ring-sky" />
            <span className="text-sm text-navy-600">Available for booking</span>
          </label>
        </div>
      </div>
      <div className="flex gap-3 mt-4">
        <button
          onClick={() => onSave({
            ...form,
            features: form.features.split(',').map((f) => f.trim()).filter(Boolean),
          })}
          className="btn-primary text-sm"
        >
          <Check className="w-4 h-4" /> Save
        </button>
        <button onClick={onCancel} className="btn-secondary text-sm">Cancel</button>
      </div>
    </div>
  );
}
