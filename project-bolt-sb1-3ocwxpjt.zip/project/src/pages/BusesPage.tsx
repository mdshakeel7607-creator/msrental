import { Bus } from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { VehicleCard } from '@/components/VehicleCard';
import { Reveal } from '@/components/Reveal';
import { useVehicles } from '@/hooks/useVehicles';

export function BusesPage() {
  const { vehicles, loading, error } = useVehicles('bus');

  return (
    <div>
      <PageHero
        title="Bus Rental Collection"
        subtitle="Comfortable and reliable buses for group travel, weddings, corporate outings, school trips, pilgrimages, and more."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'Buses' }]}
      />

      <div className="section-padding">
        <div className="container-max">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              { title: 'School Trips', desc: 'Safe and comfortable transport for students' },
              { title: 'Corporate Outings', desc: 'Professional group travel for teams' },
              { title: 'Weddings', desc: 'Elegant transport for wedding guests' },
              { title: 'Pilgrimages', desc: 'Reliable travel for spiritual journeys' },
              { title: 'Family Tours', desc: 'Spacious buses for family vacations' },
              { title: 'Group Travel', desc: 'Any group size, any destination' },
            ].map((use, i) => (
              <Reveal key={use.title} delay={i * 80}>
                <div className="bg-lightbg rounded-xl p-5 border border-navy-50">
                  <h3 className="font-heading font-semibold text-navy-800 mb-1 text-sm">{use.title}</h3>
                  <p className="text-darknavy text-xs">{use.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-lightbg rounded-2xl h-80 animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center text-red-500 py-12">
              <p>Unable to load buses. Please try again later.</p>
            </div>
          ) : vehicles.length === 0 ? (
            <div className="text-center py-16">
              <Bus className="w-16 h-16 text-navy-200 mx-auto mb-4" />
              <p className="text-navy-400">No buses available at the moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vehicles.map((v, i) => (
                <Reveal key={v.id} delay={i * 100}>
                  <VehicleCard vehicle={v} />
                </Reveal>
              ))}
            </div>
          )}

          <p className="text-sm text-navy-400 text-center mt-12">
            Prices shown are sample rates and must be confirmed before booking.
          </p>
        </div>
      </div>
    </div>
  );
}
