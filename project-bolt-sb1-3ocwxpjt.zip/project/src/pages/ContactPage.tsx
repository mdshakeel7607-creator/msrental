import { useState } from 'react';
import {
  MessageCircle, Phone, Mail, MapPin, Clock, ChevronDown,
  CheckCircle, Info, Send,
} from 'lucide-react';
import { PageHero } from '@/components/PageHero';
import { Reveal } from '@/components/Reveal';
import { supabase } from '@/lib/supabase';
import { buildWhatsAppUrl, buildContactMessage, validateMobile } from '@/lib/utils';

export function ContactPage() {
  const [form, setForm] = useState({ name: '', phone: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What are your rental prices?',
      a: 'Our rental prices vary by vehicle type. Sedans start from \u20B93,000/day, SUVs from \u20B93,000/day, and buses from \u20B913,000/day. Final pricing depends on the vehicle, duration, and travel distance. Please contact us on WhatsApp for a customized quote.',
    },
    {
      q: 'How do I confirm a booking?',
      a: 'To confirm a booking, submit a booking enquiry through our website or WhatsApp. Our team will check availability and confirm the booking with final pricing. No booking is confirmed until you receive confirmation from MSRENTAL.',
    },
    {
      q: 'Do you provide drivers?',
      a: 'Yes, professional and experienced drivers are available on request. All our drivers are licensed, courteous, and familiar with local and outstation routes.',
    },
    {
      q: 'What are the payment terms?',
      a: 'Payment can be made via cash, UPI, or bank transfer. An advance may be required to confirm the booking. Final payment is settled at the end of the trip. [Editable placeholder — update with your specific payment terms.]',
    },
    {
      q: 'Are toll and parking charges included?',
      a: 'Toll, parking, and fuel charges are typically extra and billed as per actuals. These will be clearly communicated at the time of booking confirmation.',
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = 'Name is required';
    if (!form.phone.trim()) newErrors.phone = 'Phone number is required';
    else if (!validateMobile(form.phone)) newErrors.phone = 'Enter a valid 10-digit mobile number';
    if (!form.message.trim()) newErrors.message = 'Please enter your message';
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    const msg = buildContactMessage({ name: form.name, phone: form.phone, message: form.message });
    window.open(buildWhatsAppUrl(msg), '_blank');
    setSubmitted(true);
  };

  return (
    <div>
      <PageHero
        title="Contact Us"
        subtitle="Get in touch with MSRENTAL for bookings, enquiries, or any questions. We are here to help."
        breadcrumbs={[{ label: 'Home', path: '/' }, { label: 'Contact' }]}
      />

      {/* Contact Info Cards */}
      <section className="section-padding pb-0">
        <div className="container-max">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Reveal>
              <div className="bg-white rounded-2xl p-8 shadow-md border border-navy-50 text-center card-hover">
                <div className="bg-[#25D366]/10 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-7 h-7 text-[#25D366]" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">WhatsApp</h3>
                <p className="text-darknavy text-sm mb-4">+91 8309945900</p>
                <a
                  href={buildWhatsAppUrl('Hello MSRENTAL, I have a query.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-whatsapp"
                >
                  <MessageCircle className="w-4 h-4" />
                  Chat Now
                </a>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div className="bg-white rounded-2xl p-8 shadow-md border border-navy-50 text-center card-hover">
                <div className="bg-sky/10 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-7 h-7 text-sky" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">Phone</h3>
                <p className="text-darknavy text-sm mb-4">+91 8309945900</p>
                <a href="tel:+918309945900" className="btn-secondary text-sm">
                  <Phone className="w-4 h-4" />
                  Call Us
                </a>
              </div>
            </Reveal>
            <Reveal delay={200}>
              <div className="bg-white rounded-2xl p-8 shadow-md border border-navy-50 text-center card-hover">
                <div className="bg-navy-50 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-7 h-7 text-navy-500" />
                </div>
                <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">Email</h3>
                <p className="text-darknavy text-sm mb-4">contact@msrental.com</p>
                <a href="mailto:contact@msrental.com" className="btn-secondary text-sm">
                  <Mail className="w-4 h-4" />
                  Email Us
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Contact Form + Info */}
      <section className="section-padding">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Form */}
            <Reveal direction="left">
              <div className="bg-white rounded-2xl shadow-xl shadow-navy-500/5 p-8 border border-navy-50">
                <h2 className="font-heading font-bold text-2xl text-navy-800 mb-2">Send Us a Message</h2>
                <p className="text-darknavy text-sm mb-6">
                  Fill out the form and your message will be sent to us via WhatsApp.
                </p>

                {submitted ? (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">Message Sent!</h3>
                    <p className="text-darknavy text-sm mb-4">
                      WhatsApp has been opened with your message. Please send it to complete your enquiry.
                    </p>
                    <button
                      onClick={() => { setSubmitted(false); setForm({ name: '', phone: '', message: '' }); }}
                      className="btn-secondary"
                    >
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Your Name *</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.name ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="Your name"
                      />
                      {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Phone Number *</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.phone ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all`}
                        placeholder="10-digit mobile number"
                      />
                      {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-navy-600 mb-1">Your Message *</label>
                      <textarea
                        value={form.message}
                        onChange={(e) => setForm({ ...form, message: e.target.value })}
                        rows={5}
                        className={`w-full px-4 py-2.5 rounded-xl border ${errors.message ? 'border-red-400' : 'border-navy-100'} focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all resize-none`}
                        placeholder="How can we help you?"
                      />
                      {errors.message && <p className="text-red-500 text-xs mt-1">{errors.message}</p>}
                    </div>
                    <div className="bg-lightbg rounded-xl p-4">
                      <p className="text-xs text-navy-400 flex items-start gap-2">
                        <Info className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                        Your message will be sent via WhatsApp to +91 8309945900. Please send the WhatsApp message to complete your enquiry.
                      </p>
                    </div>
                    <button type="submit" className="btn-primary w-full">
                      <Send className="w-5 h-5" />
                      Send Message
                    </button>
                  </form>
                )}
              </div>
            </Reveal>

            {/* Business Info */}
            <Reveal direction="right">
              <div className="space-y-6">
                <div className="bg-white rounded-2xl shadow-md border border-navy-50 p-8">
                  <h2 className="font-heading font-bold text-xl text-navy-800 mb-6">Business Information</h2>
                  <div className="space-y-5">
                    <div className="flex items-start gap-4">
                      <div className="bg-navy-50 rounded-xl w-11 h-11 flex items-center justify-center shrink-0">
                        <MapPin className="w-5 h-5 text-navy-500" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-navy-800">Business Location</p>
                        <p className="text-darknavy text-sm">[Address to be updated — editable placeholder]</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="bg-navy-50 rounded-xl w-11 h-11 flex items-center justify-center shrink-0">
                        <Clock className="w-5 h-5 text-navy-500" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-navy-800">Business Hours</p>
                        <p className="text-darknavy text-sm">Mon to Sun: 6:00 AM to 10:00 PM [editable placeholder]</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="bg-navy-50 rounded-xl w-11 h-11 flex items-center justify-center shrink-0">
                        <Phone className="w-5 h-5 text-navy-500" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-navy-800">Phone / WhatsApp</p>
                        <p className="text-darknavy text-sm">+91 8309945900</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="bg-navy-50 rounded-xl w-11 h-11 flex items-center justify-center shrink-0">
                        <Mail className="w-5 h-5 text-navy-500" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-navy-800">Email</p>
                        <p className="text-darknavy text-sm">contact@msrental.com [editable placeholder]</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Map Placeholder */}
                <div className="bg-lightbg rounded-2xl p-8 border border-navy-50 text-center">
                  <MapPin className="w-12 h-12 text-navy-200 mx-auto mb-3" />
                  <h3 className="font-heading font-semibold text-navy-800 mb-1">Map Location</h3>
                  <p className="text-darknavy text-sm">
                    Map will be displayed here once the business address is configured.
                  </p>
                  <p className="text-navy-400 text-xs mt-2">
                    [Add your Google Maps embed code after setting the business address]
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-lightbg section-padding">
        <div className="container-max max-w-3xl">
          <Reveal>
            <div className="text-center mb-10">
              <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">FAQ</p>
              <h2 className="font-heading font-bold text-3xl text-navy-800">Frequently Asked Questions</h2>
            </div>
          </Reveal>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <Reveal key={i} delay={i * 60}>
                <div className="bg-white rounded-xl border border-navy-50 overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 text-left"
                  >
                    <span className="font-semibold text-navy-800 text-sm">{faq.q}</span>
                    <ChevronDown
                      className={`w-5 h-5 text-navy-400 transition-transform shrink-0 ${openFaq === i ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-5 text-darknavy text-sm leading-relaxed animate-fade-in">
                      {faq.a}
                    </div>
                  )}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
