import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldCheck, Clock, Users, MessageCircle, Star, ArrowRight,
  Car, Bus, Calendar, MapPin, CheckCircle, Phone, TrendingDown,
} from 'lucide-react';
import { VehicleCard } from '@/components/VehicleCard';
import { Reveal } from '@/components/Reveal';
import { StarRating } from '@/components/StarRating';
import { supabase, type Vehicle, type Review } from '@/lib/supabase';
import { buildWhatsAppUrl, buildBookingMessage, formatPrice, formatCategory } from '@/lib/utils';

export function HomePage() {
  const navigate = useNavigate();
  const [featuredVehicles, setFeaturedVehicles] = useState<Vehicle[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [quickForm, setQuickForm] = useState({
    pickupLocation: '',
    destination: '',
    vehicleType: '',
    pickupDate: '',
    returnDate: '',
    passengers: '1',
  });

  useEffect(() => {
    Promise.all([
      supabase.from('vehicles').select('*').limit(3).order('price_per_day'),
      supabase.from('reviews').select('*').eq('approved', true).order('created_at', { ascending: false }).limit(3),
    ]).then(([vRes, rRes]) => {
      setFeaturedVehicles(vRes.data || []);
      setReviews(rRes.data || []);
      setLoading(false);
    });
  }, []);

  const handleQuickBook = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = buildBookingMessage({
      vehicleName: quickForm.vehicleType || 'a vehicle',
      pickupLocation: quickForm.pickupLocation,
      destination: quickForm.destination,
      pickupDate: quickForm.pickupDate,
      returnDate: quickForm.returnDate,
      passengers: quickForm.passengers,
    });
    window.open(buildWhatsAppUrl(msg), '_blank');
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/5063634/pexels-photo-5063634.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600"
            alt="Luxury car on highway at sunset"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-900/95 via-navy-800/80 to-navy-700/40" />
        </div>

        <div className="relative container-max px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6 animate-fade-in-down">
              <CheckCircle className="w-4 h-4 text-sky" />
              <span className="text-sm text-white font-medium">Trusted Car & Bus Rental Service</span>
            </div>
            <h1 className="font-heading font-bold text-4xl md:text-6xl text-white leading-tight mb-6 animate-fade-in-up">
              Find the Perfect Ride for <span className="text-sky">Every Journey</span>
            </h1>
            <p className="text-lg md:text-xl text-navy-100 mb-8 max-w-2xl animate-fade-in-up" style={{ animationDelay: '100ms' }}>
              Reliable cars and buses for family trips, business travel, weddings, and group journeys.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
              <Link to="/cars" className="btn-primary bg-sky hover:bg-sky-dark text-white">
                Explore Vehicles
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/book" className="btn-secondary border-white text-white hover:bg-white hover:text-navy-800">
                Book Your Ride
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Booking Form */}
      <section className="relative -mt-20 z-10 px-4">
        <div className="container-max">
          <Reveal>
            <div className="bg-white rounded-2xl shadow-2xl shadow-navy-500/10 p-6 md:p-8">
              <h2 className="font-heading font-bold text-xl text-navy-800 mb-6 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-sky" />
                Quick Booking
              </h2>
              <form onSubmit={handleQuickBook} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                    <input
                      type="text"
                      value={quickForm.pickupLocation}
                      onChange={(e) => setQuickForm({ ...quickForm, pickupLocation: e.target.value })}
                      placeholder="Enter pickup location"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Destination</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                    <input
                      type="text"
                      value={quickForm.destination}
                      onChange={(e) => setQuickForm({ ...quickForm, destination: e.target.value })}
                      placeholder="Enter destination"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Vehicle Type</label>
                  <select
                    value={quickForm.vehicleType}
                    onChange={(e) => setQuickForm({ ...quickForm, vehicleType: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm bg-white"
                  >
                    <option value="">Select type</option>
                    <option value="Sedan">Sedan</option>
                    <option value="SUV">SUV</option>
                    <option value="Bus">Bus</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Pickup Date</label>
                  <input
                    type="date"
                    value={quickForm.pickupDate}
                    onChange={(e) => setQuickForm({ ...quickForm, pickupDate: e.target.value })}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Return Date</label>
                  <input
                    type="date"
                    value={quickForm.returnDate}
                    onChange={(e) => setQuickForm({ ...quickForm, returnDate: e.target.value })}
                    min={quickForm.pickupDate || new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-navy-600 mb-1">Passengers</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
                    <input
                      type="number"
                      min="1"
                      value={quickForm.passengers}
                      onChange={(e) => setQuickForm({ ...quickForm, passengers: e.target.value })}
                      placeholder="1"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-navy-100 focus:ring-2 focus:ring-sky focus:border-sky outline-none transition-all text-sm"
                    />
                  </div>
                </div>
                <div className="md:col-span-2 lg:col-span-3 flex justify-end">
                  <button type="submit" className="btn-primary">
                    <MessageCircle className="w-5 h-5" />
                    Check Availability on WhatsApp
                  </button>
                </div>
              </form>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Featured Vehicles</p>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                Popular Rides for Every Need
              </h2>
              <p className="text-darknavy max-w-2xl mx-auto">
                From compact sedans to spacious buses, we have the perfect vehicle for your journey.
              </p>
            </div>
          </Reveal>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-lightbg rounded-2xl h-80 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredVehicles.map((v, i) => (
                <Reveal key={v.id} delay={i * 100}>
                  <VehicleCard vehicle={v} />
                </Reveal>
              ))}
            </div>
          )}

          <div className="text-center mt-10">
            <Link to="/cars" className="btn-secondary">
              View All Vehicles
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="bg-lightbg section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                Explore Our Fleet
              </h2>
              <p className="text-darknavy max-w-2xl mx-auto">
                Choose from our wide range of vehicles, each maintained to the highest standards.
              </p>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Car, title: 'Sedans', desc: 'Comfortable and fuel-efficient for city and outstation travel', link: '/cars?category=sedan', count: '4+ models' },
              { icon: Car, title: 'SUVs', desc: 'Spacious and powerful for family trips and group travel', link: '/cars?category=suv', count: '4+ models' },
              { icon: Bus, title: 'Buses', desc: 'Large capacity buses for group tours and events', link: '/buses', count: '3+ models' },
            ].map((cat, i) => (
              <Reveal key={cat.title} delay={i * 100}>
                <Link
                  to={cat.link}
                  className="block bg-white rounded-2xl p-8 shadow-md card-hover border border-navy-50"
                >
                  <div className="bg-navy-50 rounded-2xl w-16 h-16 flex items-center justify-center mb-5">
                    <cat.icon className="w-8 h-8 text-navy-500" />
                  </div>
                  <h3 className="font-heading font-semibold text-xl text-navy-800 mb-2">{cat.title}</h3>
                  <p className="text-darknavy text-sm mb-3">{cat.desc}</p>
                  <span className="text-sky font-semibold text-sm flex items-center gap-1">
                    {cat.count} <ArrowRight className="w-4 h-4" />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose MSRENTAL */}
      <section className="section-padding">
        <div className="container-max">
          <Reveal>
            <div className="text-center mb-12">
              <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Why Choose Us</p>
              <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                The MSRENTAL Advantage
              </h2>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: ShieldCheck, title: 'Safe & Reliable', desc: 'All vehicles are well-maintained and safety-checked.' },
              { icon: Clock, title: '24/7 Availability', desc: 'Flexible pickup and drop-off timings for your convenience.' },
              { icon: TrendingDown, title: 'Best Prices', desc: 'Competitive rental rates with no hidden charges.' },
              { icon: Users, title: 'Expert Drivers', desc: 'Experienced and professional drivers available on request.' },
            ].map((item, i) => (
              <Reveal key={item.title} delay={i * 100}>
                <div className="bg-white rounded-2xl p-6 shadow-md border border-navy-50 text-center card-hover">
                  <div className="bg-sky/10 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-7 h-7 text-sky" />
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-navy-800 mb-2">{item.title}</h3>
                  <p className="text-darknavy text-sm">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Preview */}
      {reviews.length > 0 && (
        <section className="bg-lightbg section-padding">
          <div className="container-max">
            <Reveal>
              <div className="text-center mb-12">
                <p className="text-sky font-semibold text-sm uppercase tracking-wide mb-2">Testimonials</p>
                <h2 className="font-heading font-bold text-3xl md:text-4xl text-navy-800 mb-4">
                  What Our Customers Say
                </h2>
              </div>
            </Reveal>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {reviews.map((r, i) => (
                <Reveal key={r.id} delay={i * 100}>
                  <div className="bg-white rounded-2xl p-6 shadow-md border border-navy-50">
                    <StarRating rating={r.rating} />
                    <p className="text-darknavy text-sm mt-4 mb-4 italic">"{r.review_text}"</p>
                    <div className="flex items-center gap-3">
                      <div className="bg-navy-500 text-white rounded-full w-10 h-10 flex items-center justify-center font-semibold">
                        {r.customer_name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-semibold text-navy-800 text-sm">{r.customer_name}</p>
                        {r.vehicle_name && <p className="text-xs text-navy-400">{r.vehicle_name}</p>}
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
            <div className="text-center mt-10">
              <Link to="/reviews" className="btn-secondary">
                Read More Reviews
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* WhatsApp CTA */}
      <section className="section-padding">
        <div className="container-max">
          <Reveal>
            <div className="bg-gradient-to-r from-navy-700 to-navy-500 rounded-3xl p-10 md:p-16 text-center text-white relative overflow-hidden">
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: 'radial-gradient(circle at 30% 50%, white 2px, transparent 2px)',
                backgroundSize: '50px 50px',
              }} />
              <div className="relative">
                <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">
                  Ready to Book Your Ride?
                </h2>
                <p className="text-navy-100 mb-8 max-w-2xl mx-auto">
                  Chat with us on WhatsApp for instant booking assistance and price confirmation.
                </p>
                <a
                  href={buildWhatsAppUrl(buildBookingMessage({ vehicleName: 'a vehicle' }))}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#25D366] text-white font-semibold px-8 py-4 rounded-full hover:bg-[#1da851] transition-all hover:shadow-lg hover:shadow-[#25D366]/30 active:scale-95"
                >
                  <Phone className="w-5 h-5" />
                  Chat on WhatsApp
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
