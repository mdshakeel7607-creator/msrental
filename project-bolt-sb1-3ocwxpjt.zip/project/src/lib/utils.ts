export const WHATSAPP_NUMBER = '918309945900';
export const WHATSAPP_BASE_URL = 'https://wa.me/918309945900';

export function buildWhatsAppUrl(message: string): string {
  return `${WHATSAPP_BASE_URL}?text=${encodeURIComponent(message)}`;
}

export function buildBookingMessage(params: {
  vehicleName: string;
  pickupLocation?: string;
  destination?: string;
  pickupDate?: string;
  returnDate?: string;
  passengers?: string;
}): string {
  const lines = [
    `Hello MSRENTAL, I would like to enquire about booking ${params.vehicleName}.`,
  ];
  if (params.pickupLocation) lines.push(`Pickup location: ${params.pickupLocation}`);
  if (params.destination) lines.push(`Destination: ${params.destination}`);
  if (params.pickupDate) lines.push(`Pickup date: ${params.pickupDate}`);
  if (params.returnDate) lines.push(`Return date: ${params.returnDate}`);
  if (params.passengers) lines.push(`Number of passengers: ${params.passengers}`);
  lines.push('Please confirm availability and the final rental price.');
  return lines.join('\n');
}

export function buildReviewMessage(params: {
  customerName: string;
  rating: number;
  vehicleName?: string;
  reviewText: string;
}): string {
  const lines = [
    `Hello MSRENTAL, I would like to share a review.`,
    `Name: ${params.customerName}`,
    `Rating: ${params.rating} / 5 stars`,
  ];
  if (params.vehicleName) lines.push(`Vehicle: ${params.vehicleName}`);
  lines.push(`Review: ${params.reviewText}`);
  return lines.join('\n');
}

export function buildContactMessage(params: {
  name: string;
  phone: string;
  message: string;
}): string {
  return `Hello MSRENTAL, I have a query.\nName: ${params.name}\nPhone: ${params.phone}\nMessage: ${params.message}`;
}

export function formatPrice(price: number): string {
  return `\u20B9${price.toLocaleString('en-IN')}`;
}

export function formatCategory(category: string): string {
  const map: Record<string, string> = {
    sedan: 'Sedan',
    suv: 'SUV',
    bus: 'Bus',
  };
  return map[category] || category;
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function calculateDays(pickup: string, returnDate: string): number {
  if (!pickup || !returnDate) return 0;
  const p = new Date(pickup);
  const r = new Date(returnDate);
  const diff = Math.ceil((r.getTime() - p.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(1, diff);
}

export function validateMobile(mobile: string): boolean {
  const cleaned = mobile.replace(/[\s-]/g, '');
  return /^[6-9]\d{9}$/.test(cleaned) || /^(\+91|91)?[6-9]\d{9}$/.test(cleaned);
}
