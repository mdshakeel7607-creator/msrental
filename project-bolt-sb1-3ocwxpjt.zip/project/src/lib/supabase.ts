import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Vehicle = {
  id: string;
  name: string;
  category: 'sedan' | 'suv' | 'bus';
  price_per_day: number;
  passengers: number;
  luggage: number;
  transmission: string;
  ac: boolean;
  image_url: string;
  gallery: string[];
  features: string[];
  description: string;
  available: boolean;
  created_at: string;
  updated_at: string;
};

export type Review = {
  id: string;
  customer_name: string;
  rating: number;
  vehicle_name: string;
  review_text: string;
  approved: boolean;
  source: string;
  created_at: string;
};

export type BookingEnquiry = {
  id: string;
  customer_name: string;
  mobile: string;
  email: string;
  pickup_location: string;
  destination: string;
  pickup_datetime: string;
  return_datetime: string;
  vehicle_category: string;
  vehicle_name: string;
  passengers: number;
  additional_requirements: string;
  status: string;
  created_at: string;
};

export type BusinessSettings = {
  id: string;
  business_name: string;
  whatsapp_number: string;
  address: string;
  business_hours: string;
  email: string;
};
