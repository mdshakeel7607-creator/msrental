import { useEffect, useState } from 'react';
import { supabase, type Vehicle } from '@/lib/supabase';

export function useVehicles(category?: string) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let query = supabase.from('vehicles').select('*').order('price_per_day', { ascending: true });
    if (category) query = query.eq('category', category);
    query.then(({ data, error: err }) => {
      if (err) setError(err.message);
      else setVehicles(data || []);
      setLoading(false);
    });
  }, [category]);

  return { vehicles, loading, error };
}

export function useVehicle(id: string | undefined) {
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) {
      setLoading(false);
      return;
    }
    supabase
      .from('vehicles')
      .select('*')
      .eq('id', id)
      .maybeSingle()
      .then(({ data, error: err }) => {
        if (err) setError(err.message);
        else setVehicle(data);
        setLoading(false);
      });
  }, [id]);

  return { vehicle, loading, error };
}
