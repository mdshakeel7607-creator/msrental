import { Link } from 'react-router-dom';
import { Car, Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react';
import { WHATSAPP_BASE_URL } from '@/lib/utils';

export function Footer() {
  return (
    <footer className="bg-navy-800 text-white pt-16 pb-8">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-white rounded-xl p-2">
                <Car className="w-6 h-6 text-navy-500" />
              </div>
              <span className="font-heading font-bold text-xl">MSRENTAL</span>
            </div>
            <p className="text-navy-200 text-sm leading-relaxed mb-4">
              Your Journey, Our Responsibility. Premium car and bus rental services for every occasion.
            </p>
            <a
              href={WHATSAPP_BASE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-[#25D366] font-medium text-sm hover:text-[#1da851] transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              +91 8309945900
            </a>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-navy-200">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/cars" className="hover:text-white transition-colors">Cars</Link></li>
              <li><Link to="/buses" className="hover:text-white transition-colors">Buses</Link></li>
              <li><Link to="/book" className="hover:text-white transition-colors">Book Now</Link></li>
              <li><Link to="/reviews" className="hover:text-white transition-colors">Reviews</Link></li>
              <li><Link to="/admin" className="hover:text-white transition-colors">Admin</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Our Fleet</h3>
            <ul className="space-y-2 text-sm text-navy-200">
              <li><Link to="/cars?category=sedan" className="hover:text-white transition-colors">Sedans</Link></li>
              <li><Link to="/cars?category=suv" className="hover:text-white transition-colors">SUVs</Link></li>
              <li><Link to="/buses" className="hover:text-white transition-colors">Buses</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Contact</h3>
            <ul className="space-y-3 text-sm text-navy-200">
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                <span>+91 8309945900</span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                <span>contact@msrental.com</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                <span>Address to be updated</span>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 mt-0.5 text-sky shrink-0" />
                <span>Mon to Sun: 6:00 AM to 10:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-navy-700 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-navy-300">
            &copy; {new Date().getFullYear()} MSRENTAL. All rights reserved.
          </p>
          <p className="text-sm text-navy-300">Your Journey, Our Responsibility.</p>
        </div>
      </div>
    </footer>
  );
}
