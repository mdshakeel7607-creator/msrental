import { Link } from 'react-router-dom';
import { Users, Briefcase, Settings, Snowflake, ArrowRight, MessageCircle } from 'lucide-react';
import type { Vehicle } from '@/lib/supabase';
import { formatPrice, formatCategory, buildWhatsAppUrl, buildBookingMessage } from '@/lib/utils';

export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const whatsappUrl = buildWhatsAppUrl(buildBookingMessage({ vehicleName: vehicle.name }));

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-md card-hover border border-navy-50">
      <Link to={`/vehicle/${vehicle.id}`} className="block relative overflow-hidden h-52">
        <img
          src={vehicle.image_url}
          alt={`${vehicle.name} - ${formatCategory(vehicle.category)} for rent`}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          loading="lazy"
        />
        <div className="absolute top-3 left-3 bg-navy-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
          {formatCategory(vehicle.category)}
        </div>
        {!vehicle.available && (
          <div className="absolute top-3 right-3 bg-red-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
            Not Available
          </div>
        )}
      </Link>

      <div className="p-5">
        <h3 className="font-heading font-semibold text-lg text-navy-800 mb-1">{vehicle.name}</h3>
        <p className="text-2xl font-bold text-navy-500 mb-4">
          {formatPrice(vehicle.price_per_day)}
          <span className="text-sm font-normal text-navy-300">/day</span>
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4 text-sm text-darknavy">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-sky" />
            <span>{vehicle.passengers} Seater</span>
          </div>
          <div className="flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-sky" />
            <span>{vehicle.luggage} Bags</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-sky" />
            <span>{vehicle.transmission}</span>
          </div>
          <div className="flex items-center gap-2">
            <Snowflake className="w-4 h-4 text-sky" />
            <span>{vehicle.ac ? 'AC' : 'Non-AC'}</span>
          </div>
        </div>

        <div className="flex gap-2">
          <Link
            to={`/vehicle/${vehicle.id}`}
            className="flex-1 inline-flex items-center justify-center gap-1 rounded-full border-2 border-navy-200 px-4 py-2.5 text-sm font-semibold text-navy-700 transition-all hover:bg-navy-500 hover:text-white hover:border-navy-500"
          >
            View Details
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 btn-whatsapp"
          >
            <MessageCircle className="w-4 h-4" />
            Book
          </a>
        </div>
      </div>
    </div>
  );
}
