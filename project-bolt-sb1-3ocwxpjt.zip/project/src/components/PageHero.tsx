import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export function PageHero({
  title,
  subtitle,
  breadcrumbs,
  children,
}: {
  title: string;
  subtitle?: string;
  breadcrumbs?: { label: string; path?: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="relative bg-navy-800 text-white overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-navy-700 via-navy-800 to-navy-900" />
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 30%, white 1px, transparent 1px)',
        backgroundSize: '60px 60px',
      }} />
      <div className="relative container-max px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        {breadcrumbs && (
          <nav className="flex items-center gap-2 text-sm text-navy-200 mb-4 animate-fade-in">
            {breadcrumbs.map((bc, i) => (
              <span key={i} className="flex items-center gap-2">
                {bc.path ? (
                  <Link to={bc.path} className="hover:text-white transition-colors">{bc.label}</Link>
                ) : (
                  <span className="text-white">{bc.label}</span>
                )}
                {i < breadcrumbs.length - 1 && <ChevronRight className="w-3 h-3" />}
              </span>
            ))}
          </nav>
        )}
        <h1 className="font-heading font-bold text-3xl md:text-5xl mb-4 animate-fade-in-up">{title}</h1>
        {subtitle && (
          <p className="text-lg text-navy-100 max-w-2xl animate-fade-in-up" style={{ animationDelay: '100ms' }}>
            {subtitle}
          </p>
        )}
        {children}
      </div>
    </section>
  );
}
