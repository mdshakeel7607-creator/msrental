import { MessageCircle } from 'lucide-react';
import { WHATSAPP_BASE_URL } from '@/lib/utils';

export function WhatsAppFloat() {
  return (
    <a
      href={WHATSAPP_BASE_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white rounded-full p-4 shadow-lg shadow-[#25D366]/40 hover:scale-110 transition-transform duration-300 animate-float-pulse"
    >
      <MessageCircle className="w-6 h-6" />
      <span className="absolute -top-1 -right-1 flex h-3 w-3">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
      </span>
    </a>
  );
}
