/*
# MSRENTAL — Seed Initial Vehicle Data

Inserts 11 initial vehicle listings: 4 sedans, 4 SUVs, 3 buses.
All prices are sample prices within the requested ranges and must be confirmed before publishing.
*/

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Maruti Suzuki Dzire', 'sedan', 5000, 5, 3, 'Manual', true,
  'https://images.pexels.com/photos/5802047/pexels-photo-5802047.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/5802047/pexels-photo-5802047.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Fuel Efficient', 'Spacious Interiors', 'Comfortable Ride', 'Power Steering'],
  'The Maruti Suzuki Dzire is a compact sedan perfect for city rides and short outstation trips. Known for its fuel efficiency and comfortable interiors.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Maruti Suzuki Dzire');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Hyundai Aura', 'sedan', 6000, 5, 3, 'Manual', true,
  'https://images.pexels.com/photos/14696345/pexels-photo-14696345.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/14696345/pexels-photo-14696345.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Modern Design', 'Touchscreen Infotainment', 'Premium Interiors', 'Fuel Efficient'],
  'The Hyundai Aura offers a premium sedan experience with modern features and stylish design. Ideal for business travel and family trips.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Hyundai Aura');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Honda City', 'sedan', 8000, 5, 4, 'Automatic', true,
  'https://images.pexels.com/photos/14120866/pexels-photo-14120866.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/14120866/pexels-photo-14120866.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Spacious Cabin', 'Automatic Transmission', 'Sunroof', 'Premium Audio'],
  'The Honda City is a premium sedan known for its spacious cabin, smooth automatic transmission, and refined driving experience. Perfect for business and leisure travel.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Honda City');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Hyundai Verna', 'sedan', 10000, 5, 4, 'Automatic', true,
  'https://images.pexels.com/photos/20573258/pexels-photo-20573258.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/20573258/pexels-photo-20573258.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Luxury Interiors', 'Turbo Engine', 'Ventilated Seats', 'Sunroof'],
  'The Hyundai Verna is a luxury sedan with advanced features, powerful turbo engine, and premium interiors. Ideal for weddings and executive travel.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Hyundai Verna');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Mahindra Bolero', 'suv', 3000, 7, 4, 'Manual', true,
  'https://images.pexels.com/photos/19806867/pexels-photo-19806867.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/19806867/pexels-photo-19806867.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Rugged Build', 'High Ground Clearance', 'Spacious', 'Fuel Efficient'],
  'The Mahindra Bolero is a rugged SUV built for tough terrains and rural routes. Ideal for group travel in challenging road conditions.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Mahindra Bolero');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Kia Carens', 'suv', 5000, 7, 4, 'Automatic', true,
  'https://images.pexels.com/photos/38715203/pexels-photo-38715203.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/38715203/pexels-photo-38715203.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['3-Row Seating', 'Premium Features', 'Sunroof', 'Ventilated Seats'],
  'The Kia Carens is a premium 3-row MPV offering comfort, space, and modern features. Perfect for family trips and group travel.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Kia Carens');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Hyundai Creta', 'suv', 7000, 5, 4, 'Automatic', true,
  'https://images.pexels.com/photos/11194510/pexels-photo-11194510.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/11194510/pexels-photo-11194510.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['Premium SUV', 'Panoramic Sunroof', 'Ventilated Seats', 'Advanced Safety'],
  'The Hyundai Creta is a premium mid-size SUV with a panoramic sunroof, ventilated seats, and advanced safety features. Ideal for comfortable long-distance travel.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Hyundai Creta');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT 'Toyota Innova Crysta', 'suv', 10000, 7, 5, 'Automatic', true,
  'https://images.pexels.com/photos/13598897/pexels-photo-13598897.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/13598897/pexels-photo-13598897.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['7-Seater', 'Premium Leather', 'Captain Seats', 'Excellent Ride Quality'],
  'The Toyota Innova Crysta is the gold standard for MPVs in India. Spacious, comfortable, and reliable — perfect for family trips, corporate travel, and long journeys.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = 'Toyota Innova Crysta');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT '22-Seater Mini Bus', 'bus', 13000, 22, 10, 'Manual', true,
  'https://images.pexels.com/photos/33693159/pexels-photo-33693159.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/33693159/pexels-photo-33693159.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['22 Seater', 'Pushback Seats', 'AC', 'Music System'],
  'A comfortable 22-seater mini bus ideal for small group outings, corporate trips, wedding transport, and family tours. Equipped with AC and pushback seats.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = '22-Seater Mini Bus');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT '35-Seater Tourist Bus', 'bus', 20000, 35, 15, 'Manual', true,
  'https://images.pexels.com/photos/29586609/pexels-photo-29586609.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/29586609/pexels-photo-29586609.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['35 Seater', 'AC', 'Reclining Seats', 'Large Luggage Space'],
  'A 35-seater tourist bus perfect for pilgrimages, school trips, and large group travel. Features comfortable reclining seats and ample luggage space.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = '35-Seater Tourist Bus');

INSERT INTO vehicles (name, category, price_per_day, passengers, luggage, transmission, ac, image_url, gallery, features, description, available)
SELECT '45-Seater Luxury Coach', 'bus', 30000, 45, 20, 'Manual', true,
  'https://images.pexels.com/photos/36556569/pexels-photo-36556569.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ARRAY['https://images.pexels.com/photos/36556569/pexels-photo-36556569.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'],
  ARRAY['45 Seater', 'Luxury AC', 'LED TV', 'Charging Points', 'Reclining Seats'],
  'A premium 45-seater luxury coach designed for long-distance group travel. Features LED TV, charging points, and ultra-comfortable reclining seats with AC.',
  true
WHERE NOT EXISTS (SELECT 1 FROM vehicles WHERE name = '45-Seater Luxury Coach');
