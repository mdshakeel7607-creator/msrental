/*
# MSRENTAL — Initial Database Schema

## Overview
Creates core tables for MSRENTAL: vehicles, reviews, booking_enquiries, business_settings, admin_emails.
Supports a public-facing car rental website with admin moderation.

## Tables
1. vehicles — all vehicle listings (sedans, SUVs, buses)
2. reviews — customer reviews with moderation workflow
3. booking_enquiries — booking enquiry submissions
4. business_settings — editable business information
5. admin_emails — authorized admin email addresses

## Security
- RLS enabled on all tables
- vehicles: public read, admin write
- reviews: public read (approved only), public insert, admin update/delete
- booking_enquiries: public insert, admin read/update/delete
- business_settings: public read, admin update
- Admin auth via Supabase email/password + admin_emails table check
*/

-- Admin emails table
CREATE TABLE IF NOT EXISTS admin_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

INSERT INTO admin_emails (email) VALUES ('admin@msrental.com')
ON CONFLICT (email) DO NOTHING;

-- Vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('sedan', 'suv', 'bus')),
  price_per_day integer NOT NULL,
  passengers integer NOT NULL DEFAULT 4,
  luggage integer NOT NULL DEFAULT 2,
  transmission text NOT NULL DEFAULT 'Manual',
  ac boolean NOT NULL DEFAULT true,
  image_url text NOT NULL,
  gallery text[] DEFAULT '{}',
  features text[] DEFAULT '{}',
  description text DEFAULT '',
  available boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  vehicle_name text DEFAULT '',
  review_text text NOT NULL,
  approved boolean NOT NULL DEFAULT false,
  source text NOT NULL DEFAULT 'website',
  created_at timestamptz DEFAULT now()
);

-- Booking enquiries table
CREATE TABLE IF NOT EXISTS booking_enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  mobile text NOT NULL,
  email text DEFAULT '',
  pickup_location text NOT NULL,
  destination text NOT NULL,
  pickup_datetime text NOT NULL,
  return_datetime text NOT NULL,
  vehicle_category text NOT NULL,
  vehicle_name text NOT NULL,
  passengers integer NOT NULL DEFAULT 1,
  additional_requirements text DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Business settings table
CREATE TABLE IF NOT EXISTS business_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name text NOT NULL DEFAULT 'MSRENTAL',
  whatsapp_number text NOT NULL DEFAULT '918309945900',
  address text DEFAULT '',
  business_hours text DEFAULT '',
  email text DEFAULT ''
);

INSERT INTO business_settings (business_name, whatsapp_number, address, business_hours, email)
VALUES ('MSRENTAL', '918309945900', 'Address to be updated', 'Mon to Sun: 6:00 AM to 10:00 PM', 'contact@msrental.com')
ON CONFLICT DO NOTHING;

-- Enable RLS
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE booking_enquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_emails ENABLE ROW LEVEL SECURITY;

-- Helper function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_emails
    WHERE email = (
      SELECT email FROM auth.users WHERE id = auth.uid()
    )
  );
$$;

-- Grants
GRANT SELECT ON vehicles TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON vehicles TO authenticated;
GRANT SELECT ON reviews TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON reviews TO authenticated;
GRANT INSERT ON booking_enquiries TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON booking_enquiries TO authenticated;
GRANT SELECT ON business_settings TO anon, authenticated;
GRANT UPDATE ON business_settings TO authenticated;
GRANT SELECT ON admin_emails TO authenticated;

-- Policies: vehicles
DROP POLICY IF EXISTS "public_read_vehicles" ON vehicles;
CREATE POLICY "public_read_vehicles" ON vehicles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "admin_insert_vehicles" ON vehicles;
CREATE POLICY "admin_insert_vehicles" ON vehicles FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_update_vehicles" ON vehicles;
CREATE POLICY "admin_update_vehicles" ON vehicles FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_vehicles" ON vehicles;
CREATE POLICY "admin_delete_vehicles" ON vehicles FOR DELETE TO authenticated USING (is_admin());

-- Policies: reviews
DROP POLICY IF EXISTS "public_read_approved_reviews" ON reviews;
CREATE POLICY "public_read_approved_reviews" ON reviews FOR SELECT TO anon, authenticated USING (approved = true OR is_admin());
DROP POLICY IF EXISTS "public_insert_reviews" ON reviews;
CREATE POLICY "public_insert_reviews" ON reviews FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "admin_update_reviews" ON reviews;
CREATE POLICY "admin_update_reviews" ON reviews FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_reviews" ON reviews;
CREATE POLICY "admin_delete_reviews" ON reviews FOR DELETE TO authenticated USING (is_admin());

-- Policies: booking_enquiries
DROP POLICY IF EXISTS "public_insert_bookings" ON booking_enquiries;
CREATE POLICY "public_insert_bookings" ON booking_enquiries FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "admin_read_bookings" ON booking_enquiries;
CREATE POLICY "admin_read_bookings" ON booking_enquiries FOR SELECT TO authenticated USING (is_admin());
DROP POLICY IF EXISTS "admin_update_bookings" ON booking_enquiries;
CREATE POLICY "admin_update_bookings" ON booking_enquiries FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "admin_delete_bookings" ON booking_enquiries;
CREATE POLICY "admin_delete_bookings" ON booking_enquiries FOR DELETE TO authenticated USING (is_admin());

-- Policies: business_settings
DROP POLICY IF EXISTS "public_read_settings" ON business_settings;
CREATE POLICY "public_read_settings" ON business_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "admin_update_settings" ON business_settings;
CREATE POLICY "admin_update_settings" ON business_settings FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- Policies: admin_emails
DROP POLICY IF EXISTS "admin_read_admin_emails" ON admin_emails;
CREATE POLICY "admin_read_admin_emails" ON admin_emails FOR SELECT TO authenticated USING (is_admin());

-- Revoke/Grant function execute
REVOKE EXECUTE ON FUNCTION is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_vehicles_category ON vehicles(category);
CREATE INDEX IF NOT EXISTS idx_vehicles_available ON vehicles(available);
CREATE INDEX IF NOT EXISTS idx_reviews_approved ON reviews(approved);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON booking_enquiries(status);
